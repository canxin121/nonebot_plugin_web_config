# nonebot_plugin_web_config

一个通用的config的webui热更新框架,需要开发者主动适配才可使用

配置项  
web_user: str = "admin"  
web_passed: str = "passwd"  
web_host: str = "127.0.0.1"  
web_port: int = 8666  
